FLEXARION — PRESS KIT / DOSSIER DE PRESSE
=========================================
Studio independant de jeux video base a Aix-en-Provence (France).
Site officiel : https://flexarion.timeoms.fr
Contact : contact@flexarion.timeoms.fr
Fondateurs : Timeo Morsilli (Developpeur), Hugo Banti (Modelisateur 3D), Enrique Ruiz (Developpeur)

Jeux en preparation :
- Les Veilleurs de Brume (FLX-01) — Aventure narrative (PC)
- Neon Calanques (FLX-02) — Action roguelite (PC, Consoles)
- Lisiere (FLX-03) — Puzzle contemplatif (PC, Mobile)

Palette officielle :
- Noir profond (Ink) : #090909
- Anthracite (Coal)  : #151515
- Blanc casse (Bone) : #F4F2ED
- Orange electrique  : #FF5A1F
- Violet (Pulse)     : #7C4DFF
